/* CollegePortal localStorage cleanup utility
 *
 * Use in the browser console on the same origin as the portal.
 * This script does not contact a server and cannot remove data from another
 * browser/device. It removes account data from this browser only.
 *
 * Examples:
 *   cleanupPortalData({ allAccounts: true });
 *   cleanupPortalData({ username: 'Brian1993' });
 */
(function (global) {
  'use strict';

  function normalize(username) {
    return String(username || '').trim().toLowerCase();
  }

  function readUsers() {
    try { return JSON.parse(localStorage.getItem('cp_users') || '[]'); }
    catch (_) { return []; }
  }

  function cleanupPortalData(options = {}) {
    const allAccounts = options.allAccounts === true;
    const requested = normalize(options.username);
    if (!allAccounts && !requested) {
      throw new Error('Pass { allAccounts: true } or { username: "account-name" }.');
    }

    const users = readUsers();
    const matched = allAccounts
      ? users
      : users.filter(user => normalize(user.username) === requested);
    const usernames = new Set(matched.map(user => normalize(user.username)));
    if (!allAccounts && requested) usernames.add(requested);

    const removedKeys = [];
    for (let i = localStorage.length - 1; i >= 0; i -= 1) {
      const key = localStorage.key(i);
      if (!key) continue;
      const isGlobalAccountData = allAccounts && ['cp_users', 'cp_session', 'cp_activity_logs'].includes(key);
      const separator = key.indexOf('_');
      const keyOwner = separator >= 0 ? normalize(key.slice(separator + 1)) : '';
      const isUserData = ['attendance', 'assignments', 'payments'].includes(key.slice(0, separator)) && usernames.has(keyOwner);
      const isTargetSession = key === 'cp_session' && (!requested ||
        (() => { try { return normalize(JSON.parse(localStorage.getItem(key)).username) === requested; } catch (_) { return false; } })());
      if (isGlobalAccountData || isUserData || isTargetSession) {
        localStorage.removeItem(key);
        removedKeys.push(key);
      }
    }

    if (!allAccounts) {
      try {
        const logs = JSON.parse(localStorage.getItem('cp_activity_logs') || '[]');
        const remainingLogs = logs.filter(log => !usernames.has(normalize(log.username)));
        if (remainingLogs.length) localStorage.setItem('cp_activity_logs', JSON.stringify(remainingLogs));
        else localStorage.removeItem('cp_activity_logs');
      } catch (_) {
        localStorage.removeItem('cp_activity_logs');
      }
    }

    // For a targeted cleanup, remove only that account from the account list.
    if (!allAccounts) {
      const remaining = users.filter(user => !usernames.has(normalize(user.username)));
      if (remaining.length) localStorage.setItem('cp_users', JSON.stringify(remaining));
      else localStorage.removeItem('cp_users');
    }

    console.info(`CollegePortal cleanup complete. Removed ${removedKeys.length} storage key(s).`, removedKeys);
    return removedKeys;
  }

  global.cleanupPortalData = cleanupPortalData;
  console.info('Cleanup utility loaded. Run cleanupPortalData({ allAccounts: true }) or cleanupPortalData({ username: "..." }).');
})(window);
