/* ============================================================
   College Portal — Shared App Logic
   app.js — localStorage layer, auth, sidebar renderer
   ============================================================ */

/* ── Auth Helpers ── */
const Auth = {
  key: 'cp_session',
  usersKey: 'cp_users',
  passwordIterations: 150000,

  normalizeUsername(username) {
    return String(username || '').trim().toLowerCase();
  },

  async hashPassword(password, salt = crypto.getRandomValues(new Uint8Array(16))) {
    const encoded = new TextEncoder().encode(password);
    const key = await crypto.subtle.importKey('raw', encoded, 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt, iterations: this.passwordIterations, hash: 'SHA-256' },
      key,
      256
    );
    const toBase64 = bytes => btoa(String.fromCharCode(...bytes));
    return `pbkdf2$sha256$${this.passwordIterations}$${toBase64(salt)}$${toBase64(new Uint8Array(bits))}`;
  },

  async verifyPassword(password, stored) {
    if (!stored) return false;
    // Legacy compatibility: upgrade plaintext passwords after a successful login.
    if (!stored.startsWith('pbkdf2$')) return stored === password;
    const [, algorithm, iterations, saltText, hashText] = stored.split('$');
    if (algorithm !== 'sha256' || !iterations || !saltText || !hashText) return false;
    const fromBase64 = text => Uint8Array.from(atob(text), c => c.charCodeAt(0));
    const encoded = new TextEncoder().encode(password);
    const key = await crypto.subtle.importKey('raw', encoded, 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: fromBase64(saltText), iterations: Number(iterations), hash: 'SHA-256' },
      key,
      256
    );
    const actual = fromBase64(hashText);
    const expected = new Uint8Array(bits);
    return actual.length === expected.length && actual.every((value, i) => value === expected[i]);
  },

  getUsers() {
    try { return JSON.parse(localStorage.getItem(this.usersKey) || '[]'); }
    catch (_) { return []; }
  },

  saveUsers(users) {
    localStorage.setItem(this.usersKey, JSON.stringify(users));
  },

  async register(data) {
    const users = this.getUsers();
    const username = this.normalizeUsername(data.username);
    if (!username) return { ok: false, msg: 'Username is required.' };
    if (users.find(u => this.normalizeUsername(u.username) === username)) return { ok: false, msg: 'Username already taken.' };
    const { password, ...profile } = data;
    users.push({ ...profile, username, password: await this.hashPassword(password) });
    this.saveUsers(users);
    return { ok: true };
  },

  async login(username, password, role) {
    const users = this.getUsers();
    const normalized = this.normalizeUsername(username);
    const user = users.find(u => this.normalizeUsername(u.username) === normalized && u.role === role);
    if (!user) return false;
    if (!(await this.verifyPassword(password, user.password))) return false;
    if (!user.password.startsWith('pbkdf2$')) {
      user.password = await this.hashPassword(password);
      this.saveUsers(users);
    }
    localStorage.setItem(this.key, JSON.stringify(user));
    return true;
  },

  logout() {
    localStorage.removeItem(this.key);
    window.location.href = rootPath() + 'index.html';
  },

  current() {
    const s = localStorage.getItem(this.key);
    return s ? JSON.parse(s) : null;
  },

  require() {
    const u = this.current();
    if (!u) { window.location.href = rootPath() + 'index.html'; return null; }
    return u;
  }
};

/* ── Local Data + Audit Log ──
   Browser storage is local to this device/browser. Do not store sensitive
   secrets such as passwords in audit logs. A real production system should
   use a secure server/database instead of client-side localStorage.
   ─────────────────────────────────────────────────────────────── */
const DataLog = {
  key: 'cp_activity_logs',

  getAll() {
    try { return JSON.parse(localStorage.getItem(this.key) || '[]'); }
    catch (_) { return []; }
  },

  add(action, details = {}) {
    const user = Auth.current();
    const entry = {
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random()),
      timestamp: new Date().toISOString(),
      date: new Date().toLocaleDateString('en-PH'),
      time: new Date().toLocaleTimeString('en-PH'),
      username: user?.username || details.username || 'anonymous',
      userRole: user?.role || details.role || 'anonymous',
      action,
      details: { ...details }
    };
    // Never write a password to logs.
    delete entry.details.password;
    const logs = this.getAll();
    logs.unshift(entry);
    localStorage.setItem(this.key, JSON.stringify(logs.slice(0, 500)));
    return entry;
  },

  clear() {
    localStorage.removeItem(this.key);
  }
};

const DataStorage = {
  folderHandle: null,

  // Gives the application a clear description of where browser data lives.
  location() {
    return 'This browser/device: localStorage (origin-specific storage)';
  },

  listLocalData() {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;
      try { data[key] = JSON.parse(localStorage.getItem(key)); }
      catch (_) { data[key] = localStorage.getItem(key); }
    }
    return data;
  },

  exportJSON(filename = 'college-portal-data.json') {
    const payload = {
      exportedAt: new Date().toISOString(),
      storageLocation: this.location(),
      data: this.listLocalData()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    DataLog.add('export_data', { filename });
  },

  async chooseLocalFolder() {
    if (!window.showDirectoryPicker) {
      throw new Error('This browser does not support direct local-folder access. Use Export JSON instead.');
    }
    this.folderHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
    DataLog.add('select_local_folder', { folderName: this.folderHandle.name });
    return this.folderHandle.name;
  },

  async saveJSONToLocalFolder(filename = 'college-portal-data.json') {
    if (!this.folderHandle) await this.chooseLocalFolder();
    const fileHandle = await this.folderHandle.getFileHandle(filename, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(JSON.stringify({
      exportedAt: new Date().toISOString(),
      data: this.listLocalData()
    }, null, 2));
    await writable.close();
    DataLog.add('save_local_file', { filename, folderName: this.folderHandle.name });
    return filename;
  }
};

// Wrap registration/login so important account events are timestamped.
const _register = Auth.register.bind(Auth);
Auth.register = async function(data) {
  const result = await _register(data);
  if (result.ok) DataLog.add('register', { username: data.username, role: data.role });
  return result;
};

const _login = Auth.login.bind(Auth);
Auth.login = async function(username, password, role) {
  const result = await _login(username, password, role);
  if (result) DataLog.add('login', { username, role });
  else DataLog.add('login_failed', { username, role });
  return result;
};

const _logout = Auth.logout.bind(Auth);
Auth.logout = function() {
  DataLog.add('logout');
  return _logout();
};

/* ── Root Path Helper ── */
function rootPath() {
  const p = window.location.pathname;
  if (p.includes('/dashboard/') || p.includes('/attendance/') ||
      p.includes('/assignments/') || p.includes('/payments/') || p.includes('/auth/')) {
    return '../';
  }
  return './';
}

/* ── Storage Helpers ── */
const Store = {
  get(key, def = []) {
    const u = Auth.current();
    const fullKey = u ? `${key}_${u.username}` : key;
    const val = localStorage.getItem(fullKey);
    return val !== null ? JSON.parse(val) : def;
  },
  set(key, value) {
    const u = Auth.current();
    const fullKey = u ? `${key}_${u.username}` : key;
    localStorage.setItem(fullKey, JSON.stringify(value));
    DataLog.add('data_write', { key: fullKey, itemType: Array.isArray(value) ? 'array' : typeof value });
  }
};

/* ── Date Helpers ── */
function today() {
  return new Date().toISOString().split('T')[0];
}

function formatDate(d) {
  if (!d) return '—';
  const dt = new Date(d + 'T00:00:00');
  return dt.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
}

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().split('T')[0];
}

/* ── Sidebar Renderer ── */
function initSidebar(activePage) {
  const user = Auth.require();
  if (!user) return;

  const root = rootPath();

  const nav = [
    { href: root + 'dashboard/dashboard.html', icon: '⊞', label: 'Dashboard', id: 'dashboard' },
    { href: root + 'attendance/attendance.html', icon: '✓', label: 'Attendance', id: 'attendance' },
    { href: root + 'assignments/assignments.html', icon: '📄', label: 'Assignments', id: 'assignments' },
    { href: root + 'payments/payments.html', icon: '💳', label: 'Payments', id: 'payments' },
    { href: root + 'data.html', icon: '🗄️', label: 'Data & Logs', id: 'data' },
  ];

  const initials = (user.firstName[0] || '') + (user.lastName[0] || '');

  const sidebar = document.getElementById('sidebar');
  if (!sidebar) return;

  sidebar.innerHTML = `
    <div class="sidebar-brand">
      <span class="logo-mark">CollegePortal</span>
      <span class="logo-sub">Student Information System</span>
    </div>
    <div class="sidebar-user">
      <div class="avatar">${initials.toUpperCase()}</div>
      <div class="sidebar-user-info">
        <div class="name">${user.firstName} ${user.lastName}</div>
        <div class="role">${user.role}</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Main Menu</div>
      ${nav.map(item => `
        <a href="${item.href}" class="nav-link ${activePage === item.id ? 'active' : ''}">
          <span class="icon">${item.icon}</span>
          ${item.label}
        </a>
      `).join('')}
    </nav>
    <div class="sidebar-footer">
      <button class="logout-btn" onclick="Auth.logout()">
        <span class="icon">⏻</span> Logout
      </button>
    </div>
  `;
}

/* ── Degree-Level Course Mapping ── */
const coursesByLevel = {
  bachelor: [
    'Mathematics', 'English Communication', 'Natural Science',
    'Filipino Subject', 'Physical Education', 'Core Major Subject',
    'General Education', 'Basic Research Methods'
  ],
  master: [
    'Advanced Research Methods', 'Graduate Seminar', 'Thesis Writing',
    'Specialized Theory', 'Educational Leadership', 'Curriculum Development',
    'Advanced Statistics', 'Practicum / Internship'
  ],
  phd: [
    'Doctoral Research', 'Dissertation Writing', 'Advanced Theoretical Frameworks',
    'Research Paradigms', 'Scholarly Publication', 'Graduate Colloquium',
    'Independent Study', 'Academic Writing'
  ]
};

function getSubjectsForUser(user) {
  const degrees = user.degrees || [];
  const hasBachelor = degrees.some(d => d.startsWith('BS'));
  const hasMaster   = degrees.some(d => d.startsWith('Master'));
  const hasPhD      = degrees.some(d => d.startsWith('PhD'));
  let subjects = [];
  if (hasBachelor) subjects = subjects.concat(coursesByLevel.bachelor);
  if (hasMaster)   subjects = subjects.concat(coursesByLevel.master);
  if (hasPhD)      subjects = subjects.concat(coursesByLevel.phd);
  if (subjects.length === 0) subjects = coursesByLevel.bachelor;
  return subjects;
}

/* ── Toast Notification ── */
function showAlert(id, message, type = 'error') {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `alert alert-${type} show`;
  el.innerHTML = `<span>${message}</span>`;
  setTimeout(() => { el.classList.remove('show'); }, 4000);
}

/* ── Seed Demo Users ── */
(async function seedDemoUsers() {
  const users = Auth.getUsers();
  if (users.length === 0) {
    Auth.saveUsers([{
      username: 'brian1993',
      password: await Auth.hashPassword('Terence Cr'),
      role: 'student',
      firstName: 'Brian',
      lastName: 'Santos',
      middleName: 'Cruz',
      birthdate: '1993-06-15',
      address: '123 Quirino Ave, Manila',
      email: 'brian1993@gmail.com',
      degrees: ['BS in Computer Science'],
      tuition: 15000
    }]);
  }
})();
