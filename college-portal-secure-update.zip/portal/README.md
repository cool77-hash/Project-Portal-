# CollegePortal — Development Notice and Copyright

> **Copyright and permission notice:** This project and its source code, design, interface, text, sample records, branding, and other included materials are proprietary development materials unless a separate written license says otherwise.
>
> **Do not copy, modify, publish, deploy, distribute, demonstrate publicly, or use this project commercially without obtaining prior permission from the copyright owner or authorized project administrator.**

## Development status

CollegePortal is **under active development**. It is a prototype and is not represented as a finished, production-ready student information system.

Features, data structures, authentication behavior, user interface elements, and security controls may change without notice. Some included records and interface content are sample or demonstration data only.

## Required permission before use

You must obtain explicit permission from the user, copyright owner, or authorized administrator before you:

- use this project outside its authorized development environment;
- deploy it to a public or private server;
- connect it to real student, faculty, staff, payment, attendance, or assignment data;
- share the source code or screenshots publicly;
- remove or change this notice; or
- integrate it into another product or service.

Receiving a copy of the files does **not** by itself grant a license, ownership interest, or permission to deploy or redistribute them.

## Do not deploy immediately

**Do not deploy this project immediately or use it with real personal information.** Proper testing, security review, privacy review, access-control review, and approval are required first.

An unsafe or premature deployment may expose personal information, allow unauthorized access, corrupt records, or create data-loss and compliance risks. In particular, do not enter real passwords, addresses, birthdates, email addresses, payment information, attendance records, or academic records into this prototype until it has been replaced or approved for that purpose.

## Current technical limitations

This archive is currently a **front-end-only prototype**:

- It consists of HTML, CSS, and JavaScript files.
- It has no production domain configured.
- It has no backend service or API.
- It has no server-side database.
- It has no production identity provider or server-side access control.
- Its demo data and browser data are stored locally in `localStorage` for the current browser origin.
- Local browser storage is not a suitable production database or secure multi-user account system.
- Clearing browser storage, changing browsers, or changing devices can make locally stored data unavailable.
- A public deployment would still require a backend, database, secure authentication, authorization, validation, backups, monitoring, HTTPS, and an approved privacy/security design.

## Security note

The current source includes a compatibility migration for older accounts that may have stored plaintext passwords. A successful login upgrades such an account to a PBKDF2-derived password hash in the current browser. This is a development safeguard, not a substitute for a production authentication service.

Before any production use, conduct a full security review and migrate account authentication to a properly configured server-side identity system. Never rely on client-side JavaScript or `localStorage` to protect real credentials or sensitive records.

## Cleanup utility

`cleanup-local-data.js` can remove portal data from the current browser origin. It cannot remove data from other browsers, devices, servers, backups, exports, or downloads.

Use it only after confirming the intended deletion scope:

```javascript
cleanupPortalData({ username: "account-name" });
```

To remove all portal data from the current browser origin:

```javascript
cleanupPortalData({ allAccounts: true });
```

Deletion may be irreversible. Export or preserve any authorized test data before cleanup if it is needed for development.

## Testing and approval checklist

Before considering deployment, obtain authorization and complete at least the following:

- security and privacy review;
- authentication and authorization testing;
- input validation and output-encoding testing;
- cross-user data-isolation testing;
- backup, restore, and deletion testing;
- browser, mobile, and accessibility testing;
- dependency and source-code review;
- backend and database implementation;
- HTTPS, domain, hosting, logging, monitoring, and incident-response setup; and
- written approval for the intended users, data, environment, and deployment scope.

## No warranty

This development prototype is provided for authorized evaluation and development only. It is not a complete or production-ready system. No warranty is made regarding security, availability, correctness, legal compliance, privacy protection, or suitability for any particular purpose.

## Contact and authorization

For permission to use, modify, deploy, publish, or redistribute this project, contact the copyright owner or the authorized project administrator before taking action.
