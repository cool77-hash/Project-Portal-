const $=s=>document.querySelector(s),app=$('#app'),
esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const NAV=[['about','About'],['street','Street'],['performance','Performance'],['competition','Competition'],['builds','Builds'],['book','Book']];
const ST=['Street','Local Drift','Amateur','Advanced','PROSPEC'];
const STEPS=['Consultation','Build plan','Dyno / setup','Track test','Final tuning','Delivery / support'];
const SVC=['Street build','Performance tuning','Dyno & ECU','Alignment & suspension','Competition preparation'];
const S={vehicles:['My vehicles','2002 Honda S2000'],builds:['My builds','Build name or goal'],service:['Service history','e.g. Alignment, 12 Oct'],dyno:['Dyno results','287 Nm/383hp'],track:['Track tests','2:39:32'],orders:['Orders','Part and order number']};
const B=[{id:1,n:'Supra Mk 5',tag:'Street',img:'b1',hp:'382 hp',parts:['Coilovers','Forged wheels','Front lip']},
{id:2,n:'EVO X',tag:'Performance',img:'b2',hp:'420 hp',parts:['Front-mount intercooler','ECU tune','Big brake kit']},
{id:3,n:'S13',tag:'Competition',img:'b3',hp:'510 hp',parts:['Angle kit','Welded diff','Roll cage']},
{id:4,n:'S15',tag:'Competition',img:'b4',hp:'480 hp',parts:['Wide-body kit','Drift suspension','Hydraulic handbrake']}];
const PG={
about:{img:'about',t:'About us',sub:'Philosophy, services and progression.',h:'From street machines to competition builds',p:'Performance development for Japanese drift cars — from enthusiasts to PROSPEC competition.',
 d:['Company story',"Kansei Driftworks is a Japanese performance and drift tuning company dedicated to turning JDM cars into capable, driver-focused machines. From street builds to professional competition, we combine quality parts, precise tuning, dyno development, and track testing to unlock the car's full potential."],
 chips:[['Street','style / drivability','Looks right and drives right on public roads.'],['Local drift','setup / events','Setup and support for your first local events.'],['Amateur','competition','Reliable, tested setups for amateur competition.'],['PROSPEC','professional path','Data-driven builds for the professional level.']],
 box:['Services summary','Parts • Styling • Performance • Dyno • Track testing • Competition preparation','“Every component is selected for a reason. Every setup is tested for results.”'],cta:['Book a service','#/book']},
street:{img:'street',t:'Street builds',sub:'Where the left car leads.',h:'Make your car yours.',d:['','Turn a stock JDM platform into a street car that looks right, drives right, and performs when the road opens up.'],
 chips:[['Body / style','','Bumpers, lips, fenders and finishes that suit the car.'],['Suspension','','Ride height and damping set for the road, not just the look.'],['Wheels / tires','','Fitment, offset and tire choice matched to how you drive.']],
 box:['Street services / parts list','Body kits • Coilovers • Wheels • Tires • Alignment',''],cta:['Explore builds','#/builds']},
performance:{img:'perf',t:'Performance engineering',sub:'Where the center car leads.',h:'Power is only the beginning.',d:['Engineering','Every modification is measured, tested, and tuned around the car—not just the parts list.'],
 chips:[['Engine','','Reliable power targets, planned with the rest of the car.'],['ECU / dyno','','Tuned on the dyno, with before-and-after numbers.'],['Suspension','','Geometry and damping tuned to the power.'],['Alignment','','Camber, caster and toe set for your driving.'],['Brakes','','Pads, rotors and fluid that handle repeat use.'],['Tires','','Compound and pressure chosen for the job.']],
 box:null,cta:['View services','#/book']},
competition:{img:'comp',t:'Drift / competition',sub:'Where the right car leads.',h:'From local events to the bigger stage.',d:['Competition','Build, test, refine, and prepare the car for competition—from the first local event to professional-level competition.'],
 chips:[['Local drift','','Your first event: a safe, simple setup.'],['Amateur','','More angle, more data, more seat time.'],['Advanced','','Fabrication and tuning for harder events.'],['PROSPEC','','Full preparation for professional-level competition.']],
 box:['Competition services','Setup • Fabrication • Data • Testing • Driver-focused tuning',''],cta:['Explore builds','#/builds']}};
const MF={login:{t:'Member login',f:[['id','Email / username','text'],['password','Password','password']],b:'Log in'},
signup:{t:'Create account',f:[['username','Username','text'],['email','Email','email'],['password','Password','password']],b:'Sign up'},
forgot:{t:'Reset password',f:[['email','Email','email'],['password','New password','password']],b:'Reset password'}};
let user=null,cur='',sec='overview',q='',tag='All',done=null,PGcur=null;

const toast=m=>{const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>t.hidden=true,2800)};
const closeM=()=>{$('#modal').hidden=true};
function modal(m){const c=MF[m];
 $('#modal').innerHTML=`<div class="card" role="dialog" aria-modal="true"><button class="x" data-act="close" aria-label="Close">×</button><h2>${c.t}</h2>
 <form data-m="${m}">${c.f.map(([n,l,t])=>`<label>${l}<input name="${n}" type="${t}" required autocomplete="${t==='password'?(m==='login'?'current-password':'new-password'):'on'}"></label>`).join('')}
 <p class="err" role="alert"></p><div class="row"><button class="btn gr">${c.b}</button>${m==='login'?'<button type="button" class="btn ye" data-act="open" data-m="forgot">Forgot password?</button>':''}</div></form>
 <p class="alt">${m==='login'?`Don't have an account? <a href="#" data-act="open" data-m="signup">Sign up</a>`:`Have an account? <a href="#" data-act="open" data-m="login">Log in</a>`}</p></div>`;
 $('#modal').hidden=false;$('#modal input').focus()}

const shell=(t,s,b)=>`<header class="bar"><a class="logo" href="#/">感性 <b>Kansei</b></a><nav>${NAV.map(([k,l])=>`<a href="#/${k}" class="${cur===k?'on':''}">${l}</a>`).join('')}<a href="#/account" class="${cur==='account'?'on':''}">${user?esc(user.username):'Login'}</a></nav></header><main class="pg"><h1>${t}</h1><p class="sub">${s}</p>${b}</main>`;
const ico={f:'<svg viewBox="0 0 24 24"><path fill="#fff" d="M14 8V6.5c0-.7.3-1 1-1h2V2h-3c-3 0-4 2-4 4v2H8v3.5h2V22h4v-10.5h2.7L17 8z"/></svg>',
t:'<svg viewBox="0 0 24 24"><path fill="#fff" d="M16.5 2h-3.2v13a2.7 2.7 0 1 1-2.7-2.7c.3 0 .5 0 .8.1V9.1a6 6 0 1 0 5.1 5.9V8.6a7 7 0 0 0 4 1.3V6.7a4 4 0 0 1-4-4.7z"/></svg>',
i:'<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="#fff"/></svg>'};

function home(){
 const ctl=user?`<a class="btn cy" href="#/account"><b>My Kansei</b></a><button class="btn cy" data-act="logout"><b>Log out</b></button>`:`<button class="btn cy" data-act="open" data-m="login"><b>Login</b></button><button class="btn cy" data-act="open" data-m="signup"><b>Sign-up</b></button>`;
 return `<main class="home"><div class="stage"><img class="hero" src="img/hero.jpg" alt="Three drift cars: an AE86, a Mark II and a wide-body coupe">
 <a class="zone zl" href="#/street" style="--x:5%;--k:var(--gr)"><span>Street builds</span></a>
 <a class="zone zc" href="#/performance" style="--x:42%;--k:var(--cy)"><span>Performance</span></a>
 <a class="zone zr" href="#/competition" style="--x:79%;--k:var(--pk)"><span>Drift / competition</span></a>
 <div class="ctl">${ctl}</div>
 <div class="ttl"><b>感性 漂流物</b><span>KANSEI DRIFTWORKS</span></div>
 <div class="soc"><div class="ic"><a href="#" style="background:#1877f2" aria-label="Facebook">${ico.f}</a><a href="#" style="background:#000" aria-label="TikTok">${ico.t}</a><a href="#" style="background:linear-gradient(45deg,#fd5949,#d6249f,#285aeb)" aria-label="Instagram">${ico.i}</a></div><a class="btn cy" href="#/about"><b>About us</b></a></div></div></main>`}

function sect(k){const p=PG[k];PGcur=p;
 return shell(p.t,p.sub,`<div class="split"><figure class="ph"><img src="img/${p.img}.jpg" alt=""></figure><div>
 <div class="bx ye"><h2>${p.h}</h2>${p.p?`<p>${p.p}</p>`:''}</div>
 <div class="bx cy">${p.d[0]?`<h3>${p.d[0]}</h3>`:''}<p>${p.d[1]}</p></div>
 <div class="chips">${p.chips.map((c,i)=>`<button class="bx gr chip" data-act="chip" data-i="${i}"><b>${c[0]}</b>${c[1]?`<small>${c[1]}</small>`:''}</button>`).join('')}</div>
 <p id="detail" class="detail" aria-live="polite">Tap an item to see what it covers.</p>
 ${p.box?`<div class="bx cy"><h3>${p.box[0]}</h3><p>${p.box[1]}</p>${p.box[2]?`<em>${p.box[2]}</em>`:''}</div>`:''}
 <a class="btn ye" href="${p.cta[1]}">${p.cta[0]} →</a></div></div>`)}

function builds(){
 return shell('Featured builds','Browse real builds. Tap a card for the full build page.',`<div class="bx ye bar2"><input id="q" type="search" placeholder="Search builds" value="${esc(q)}" aria-label="Search builds"><div class="tags">${['All','Street','Performance','Competition'].map(t=>`<button class="tg ${t===tag?'on':''}" data-act="tag" data-v="${t}">${t}</button>`).join('')}</div></div><div id="grid" class="grid"></div>`)}
function grid(){const l=B.filter(b=>(tag==='All'||b.tag===tag)&&b.n.toLowerCase().includes(q.toLowerCase()));
 $('#grid').innerHTML=l.map(b=>`<a class="bc" href="#/build/${b.id}"><img src="img/${b.img}.jpg" alt="${b.n}"><div class="bx cy"><b>Build #00${b.id}</b><br>${b.n}<small>${b.tag}</small></div></a>`).join('')||'<p class="sub">No builds match. Clear the search or choose All.</p>'}
function build(id){const b=B.find(x=>x.id==id);if(!b)return shell('Build not found','','<a class="btn cy" href="#/builds">Back to builds</a>');
 return shell(`Build #00${b.id} · ${b.n}`,'Sample specs. Replace with your real build data.',`<div class="split"><figure class="ph"><img src="img/${b.img}.jpg" alt="${b.n}"></figure><div>
 <div class="bx ye"><h2>${b.hp}</h2><p>${b.tag} build</p></div><div class="bx cy"><h3>Parts</h3><ul class="plain">${b.parts.map(p=>`<li>${p}</li>`).join('')}</ul></div>
 <a class="btn gr" href="#/book/${encodeURIComponent(b.n)}">Book a build like this →</a> <a class="btn cy" href="#/builds">Back to builds</a></div></div>`)}

async function account(){
 if(!user)return shell('My Kansei','Log in to see your vehicle and service history.','<button class="btn cy" data-act="open" data-m="login">Log in</button> <button class="btn pk" data-act="open" data-m="signup">Create account</button>');
 const bk=await Api.bookings(),last=k=>esc(user[k].slice(-1)[0]||'—');
 const menu=[['overview','Overview'],['vehicles','My vehicles'],['builds','My builds'],['service','Service history'],['dyno','Dyno results'],['track','Track tests'],['appts','Appointments'],['orders','Orders'],['profile','Profile']];
 let m;
 if(sec==='overview')m=`<div class="g2"><div class="bx pk"><h3>My vehicle</h3><p class="big">${last('vehicles')}</p></div><div class="bx gr"><h3>Build status</h3><select id="st" aria-label="Build status">${ST.map(s=>`<option ${s===user.status?'selected':''}>${s}</option>`).join('')}</select></div></div>
 <div class="bx cy"><h3>Current setup</h3><p>Power • Suspension • Aero • Wheels/Tires • ECU</p></div>
 <div class="g2"><div class="bx ye"><h3>Dyno results</h3><p class="big">${last('dyno')}</p></div><div class="bx ye"><h3>Track test results</h3><p class="big">${last('track')}</p></div></div>`;
 else if(sec==='appts')m=`<h2>Appointments</h2><ul class="list">${bk.map(b=>`<li>${esc(b.service)} — ${esc(b.vehicle)}<small>${new Date(b.at).toLocaleDateString()} · Stage: ${STEPS[b.stage]}</small></li>`).join('')||'<li class="mute">No appointments yet. <a href="#/book">Request a consultation</a></li>'}</ul>`;
 else if(sec==='profile')m=`<h2>Profile</h2><ul class="list"><li>Username<small>${esc(user.username)}</small></li><li>Email<small>${esc(user.email)}</small></li></ul><button class="btn ye" data-act="logout">Log out</button>`;
 else m=`<h2>${S[sec][0]}</h2><ul class="list">${user[sec].map((v,i)=>`<li>${esc(v)}<button data-act="del" data-k="${sec}" data-i="${i}" aria-label="Remove">×</button></li>`).join('')||'<li class="mute">Nothing here yet.</li>'}</ul><form data-f="add" data-k="${sec}" class="row"><input name="v" placeholder="${S[sec][1]}" required aria-label="New entry"><button class="btn cy">Add</button></form>`;
 return shell('My Kansei','Your vehicle and service history.',`<div class="dash"><nav class="menu bx cy">${menu.map(([k,l])=>`<button class="${k===sec?'on':''}" data-act="sec" data-v="${k}">${l}</button>`).join('')}</nav><section>${m}</section></div>`)}

function book(v){
 const veh=v?decodeURIComponent(v):(user?user.vehicles.slice(-1)[0]||'':'');
 const form=done?`<div class="bx gr"><h3>Consultation requested</h3><p>We review your build goal first. No price is quoted until we understand the build.</p></div><a class="btn cy" href="#/${user?'account':''}" ${user?'data-act="sec" data-v="appts"':''}>${user?'See appointments':'Back home'}</a>`
 :`<form id="book"><label>Service type<select name="service">${SVC.map(s=>`<option>${s}</option>`).join('')}</select></label><label>Vehicle<input name="vehicle" required value="${esc(veh)}" placeholder="Year, make, model"></label><label>Contact details<input name="contact" required value="${esc(user?user.email:'')}" placeholder="Name and phone or email"></label><label>Message / build goal<textarea name="goal" rows="4" required placeholder="What do you want the car to do?"></textarea></label><p class="err" role="alert"></p><button class="btn gr">Request consultation →</button></form>`;
 return shell('Contact / booking','Consultation first. We don’t show fixed prices before the build is understood.',`<div class="split"><div class="bx pk"><h2>Book a service</h2>${form}</div><div class="bx ye"><h2>What happens next</h2><ol class="steps">${STEPS.map((s,i)=>`<li class="bx gr ${done&&i===0?'on':''}">${String(i+1).padStart(2,'0')}&nbsp; ${s}</li>`).join('')}</ol></div></div>`)}

async function render(){
 const [r,a]=(location.hash.slice(2)||'').split('/');cur=r||'home';if(cur!=='book')done=null;
 let h;
 if(!r)h=home();else if(PG[r])h=sect(r);else if(r==='builds')h=builds();else if(r==='build')h=build(a);else if(r==='account')h=await account();else if(r==='book')h=book(a);else h=shell('Page not found','','<a class="btn cy" href="#/">Back home</a>');
 app.innerHTML=h;if(r==='builds')grid();scrollTo(0,0)}

document.addEventListener('click',async e=>{
 if(e.target.id==='modal')return closeM();
 const t=e.target.closest('[data-act]');if(!t)return;const d=t.dataset,a=d.act;
 if(t.tagName==='A'&&d.m)e.preventDefault();
 if(a==='open')modal(d.m);
 else if(a==='close')closeM();
 else if(a==='logout'){await Api.logout();user=null;toast('Logged out');location.hash==='#/'?render():location.hash='#/'}
 else if(a==='chip'){document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===t));$('#detail').textContent=PGcur.chips[d.i][2]}
 else if(a==='tag'){tag=d.v;document.querySelectorAll('.tg').forEach(c=>c.classList.toggle('on',c===t));grid()}
 else if(a==='sec'){sec=d.v;render()}
 else if(a==='del'){user=await Api.update({[d.k]:user[d.k].filter((_,i)=>i!=d.i)});render()}});
document.addEventListener('submit',async e=>{e.preventDefault();const f=e.target,d=Object.fromEntries(new FormData(f));
 try{
  if(f.dataset.m){const m=f.dataset.m;
   if(m==='forgot'){await Api.forgot(d);toast('Password updated. Log in with the new one.');return modal('login')}
   user=await Api[m==='login'?'login':'register'](d);closeM();toast(m==='login'?`Welcome back, ${user.username}`:'Account created');render()}
  else if(f.dataset.f==='add'){user=await Api.update({[f.dataset.k]:[...user[f.dataset.k],d.v.trim()]});render()}
  else if(f.id==='book'){await Api.book(d);done=d;render()}
 }catch(x){const p=f.querySelector('.err');p?p.textContent=x.message:toast(x.message)}});
document.addEventListener('change',async e=>{if(e.target.id==='st'){user=await Api.update({status:e.target.value});toast('Build status: '+user.status)}});
document.addEventListener('input',e=>{if(e.target.id==='q'){q=e.target.value;grid()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeM()});
addEventListener('hashchange',render);
Api.me().then(u=>{user=u;render()});
