/* Local "backend": stores users, session and bookings in localStorage.
   Every method is async, like a real server call. To go live, replace each
   body with fetch('/api/...') and keep the same inputs and outputs. */
const Api=(()=>{
const K='kansei_db',
L=()=>JSON.parse(localStorage.getItem(K)||'{"users":[],"bookings":[],"session":null}'),
W=d=>localStorage.setItem(K,JSON.stringify(d)),
H=async s=>{s='kansei:'+s;
 if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
 let h=5381;for(const c of s)h=(h*33)^c.charCodeAt(0);return'x'+(h>>>0)},
pub=u=>{if(!u)return null;const{pass,...r}=u;return r},
find=(d,id)=>{id=id.toLowerCase();return d.users.find(u=>u.email===id||u.username.toLowerCase()===id)};
return{
async register({username,email,password}){
 const d=L();username=username.trim();email=email.trim().toLowerCase();
 if(username.length<3)throw Error('Username needs at least 3 characters.');
 if(!/^\S+@\S+\.\S+$/.test(email))throw Error('Enter a valid email address.');
 if(password.length<6)throw Error('Password needs at least 6 characters.');
 if(find(d,email)||find(d,username))throw Error('That email or username is already registered.');
 const u={id:Date.now(),username,email,pass:await H(password),status:'Street',vehicles:['2002 Honda S2000'],builds:[],service:[],dyno:['287 Nm/383hp'],track:['2:39:32'],orders:[]};
 d.users.push(u);d.session=u.id;W(d);return pub(u)},
async login({id,password}){
 const d=L(),u=find(d,id.trim());
 if(!u||u.pass!==await H(password))throw Error('Wrong email/username or password.');
 d.session=u.id;W(d);return pub(u)},
async forgot({email,password}){
 const d=L(),u=find(d,email.trim());
 if(!u)throw Error('No account uses that email.');
 if(password.length<6)throw Error('Password needs at least 6 characters.');
 u.pass=await H(password);W(d)},
async me(){const d=L();return pub(d.users.find(u=>u.id===d.session))},
async logout(){const d=L();d.session=null;W(d)},
async update(p){const d=L(),u=d.users.find(x=>x.id===d.session);Object.assign(u,p);W(d);return pub(u)},
async book(b){const d=L(),r={id:Date.now(),user:d.session,stage:0,at:new Date().toISOString(),...b};d.bookings.push(r);W(d);return r},
async bookings(){const d=L();return d.bookings.filter(b=>b.user&&b.user===d.session)}
}})();
